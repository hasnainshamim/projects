from django.apps import AppConfig


class LayoutsConfig(AppConfig):
    name = 'layouts'
